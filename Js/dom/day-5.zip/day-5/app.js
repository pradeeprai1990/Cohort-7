let loginStatus = true;
let loginPromise = new Promise((resolove, reject) => {
  if (loginStatus) {
    resolove({ status: true, message: "Login Done" });
  } else {
    reject({ status: false, message: "Invalid Username or Password" });
  }
});

// let display = async () => {

//   try {
//     let data = await loginPromise; // success ka ans
//     console.log(data.status);
//     console.log(data.message);
//   } catch (err) {
//     console.log(err);
//   }

//   // console.log(loginPromise);
//   //API
//   //FIle handling
//   //DB
// };

async function display() {
  //Core js
  try {
    let data = await loginPromise; //success //2 s // 3 //4s
    console.log(data);
  } catch (err) {
    console.log(err);
  }
}
display();

let display2 = () => {
  //React Js
  loginPromise
    .then((successRes) => {
      console.log(successRes);
    })
    .catch((err) => {
      console.log(err);
    });
};

display2();

// let l=[10,30,99,44]
// // async // await
// console.log(loginPromise);
// //Then Catch
// //

// let user = [
//   {
//     name: "Rohit",
//     age: 23,
//     city: "Delhi",
//   },
//   {
//     name: "Rahul",
//     age: 24,
//     city: "Mumbai",
//   },
// ];

// let data=JSON.stringify(user);